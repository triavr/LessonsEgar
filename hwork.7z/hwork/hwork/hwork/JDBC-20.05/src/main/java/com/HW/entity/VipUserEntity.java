package com.lebedev.entity;

public class VipUserEntity{
    private Long id;
    private Integer discount;
    private UserEntity user;
}
