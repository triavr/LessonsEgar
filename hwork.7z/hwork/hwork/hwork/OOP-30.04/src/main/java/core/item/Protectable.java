package core.item;

public interface Protectable {
    int protect();
}
