package com.lebedev;

/**
 * Интерфейс Movable описывает объекты которе могут перемещаться
 */
public interface Movable {
    void move(int x, int y);
}
