package com.lebedev;

public interface Talking {
    void sayName();
    void talk(String words);
    void sayPosition();
}
