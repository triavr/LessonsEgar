package ru.lebedev.entity;

public enum PersonStatus {
    ACTIVE, DELETE
}
