package ru.lebedev.core.entity;

public class User {
}
